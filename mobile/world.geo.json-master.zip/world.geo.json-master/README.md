To mock something fast and loose with geo-json data for the world,
this is your fix. Legal status of this dataset: dubious?

You might prefer [world-atlas](https://github.com/mbostock/world-atlas)
or [us-atlas](https://github.com/mbostock/us-atlas) instead, if that is an issue.
As a bonus, that will give you not just attributable sources, but topology preservation
across features and much smaller files than native geo-json offers. It's the future.

For a good time, drag them to http://bl.ocks.org/1431429 and paint the globe!
